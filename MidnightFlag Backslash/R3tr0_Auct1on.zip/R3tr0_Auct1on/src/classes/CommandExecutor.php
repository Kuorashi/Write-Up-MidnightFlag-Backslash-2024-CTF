<?php
class CommandExecutor {
    public function __construct($cmd) {
        echo shell_exec($cmd);
    }
}
?>
