<?php
class FileReader {
    public function __construct($filename) {
        echo file_get_contents($filename);
    }
}
?>
