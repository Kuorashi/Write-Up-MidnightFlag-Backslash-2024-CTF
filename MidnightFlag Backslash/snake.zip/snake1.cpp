#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <thread>
#include <chrono>
#ifdef _WIN32
#include <conio.h>
#else
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#endif

using namespace std;

enum eDirection { STOP = 0, LEFT, RIGHT, UP, DOWN };
eDirection dir;

int width = 60, height = 30;
int x, y, fruitX, fruitY, score;
bool gameOver;
vector<pair<int,int>> tail;

void Setup() {
    gameOver = false;
    dir = STOP;
    x = width / 2;
    y = height / 2;
    fruitX = rand() % width;
    fruitY = rand() % height;
    score = 0;
}

void ClearScreen() {
    #ifdef _WIN32
    system("cls");
    #else
    cout << "\033[2J\033[1;1H";
    #endif
}

#ifndef _WIN32
// Fonctions pour la lecture non bloquante des entrées clavier sur Unix/Linux
void initTermios(int echo) {
    struct termios newt;
    tcgetattr(STDIN_FILENO, &newt);
    newt.c_lflag &= ~ICANON;
    newt.c_lflag &= echo ? ECHO : ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
}

void resetTermios(void) {
    struct termios newt;
    tcgetattr(STDIN_FILENO, &newt);
    newt.c_lflag |= ICANON;
    newt.c_lflag |= ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
}

char getch(void) {
    char ch;
    initTermios(0);
    ch = getchar();
    resetTermios();
    return ch;
}

int kbhit(void) {
    struct termios oldt, newt;
    int ch;
    int oldf;
  
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
  
    ch = getchar();
  
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
  
    if(ch != EOF) {
        ungetc(ch, stdin);
        return 1;
    }
  
    return 0;
}

void Input() {
    if (kbhit()) {
        switch (getch()) {
            case 'z':
                if (dir != DOWN) dir = UP;
                break;
            case 's':
                if (dir != UP) dir = DOWN;
                break;
            case 'q':
                if (dir != RIGHT) dir = LEFT;
                break;
            case 'd':
                if (dir != LEFT) dir = RIGHT;
                break;
            case 'x': // Quitter le jeu
                gameOver = true;
                break;
        }
    }
}
#else
void Input() {
    if (_kbhit()) {
        switch (_getch()) {
        case 'z':
            if (dir != DOWN) dir = UP;
            break;
        case 's':
            if (dir != UP) dir = DOWN;
            break;
        case 'q':
            if (dir != RIGHT) dir = LEFT;
            break;
        case 'd':
            if (dir != LEFT) dir = RIGHT;
            break;
        case 'x': // Quitter le jeu
            gameOver = true;
            break;
        }
    }
}
#endif

void Draw() {
    ClearScreen();
    for (int i = 0; i < width + 2; i++)
        cout << "#";
    cout << endl;

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (j == 0 || j == width - 1 || i == 0 || i == height - 1) cout << "#";
            else if (i == y && j == x) cout << "O";
            else if (i == fruitY && j == fruitX) cout << "F";
            else {
                bool print = false;
                for (auto t : tail) {
                    if (t.first == i && t.second == j) {
                        cout << "o";
                        print = true;
                        break;
                    }
                }
                if (!print) cout << " ";
            }
        }
        cout << "#" << endl;
    }

    for (int i = 0; i < width + 2; i++)
        cout << "#";
    cout << "\nScore:" << score << endl;
}

std::string encryptedFlag = "#+6~3ki62k;o.~*i9`4k%";
std::string encryptDecrypt(const std::string& toEncrypt) {
    char key = 'X'; // Clé de cryptage/décryptage; peut être n'importe quel caractère
    std::string output = toEncrypt;

    for (size_t i = 0; i < toEncrypt.size(); i++) {
        output[i] = toEncrypt[i] ^ key;
    }

    return output;
}
void Logic() {
    pair<int, int> prev = {y, x};
    pair<int, int> prev2;

    if (!tail.empty()) {
        prev2 = tail[0];
        tail[0] = prev;
        for (size_t i = 1; i < tail.size(); i++) {
            swap(tail[i], prev2);
        }
    }

    switch (dir) {
    case LEFT:
        x--;
        break;
    case RIGHT:
        x++;
        break;
    case UP:
        y--;
        break;
    case DOWN:
        y++;
        break;
    default:
        break;
    }

    // Collision avec les bords
    if (x == 0 || x == width-1 || y == 0 || y == height-1) gameOver = true;

    for (pair<int, int> segment : tail) {
        if (segment.first == y && segment.second == x) {
            gameOver = true;
            break;
        }
    }

    if (x == fruitX && y == fruitY) {
        score += 10;
        fruitX = rand() % width;
        fruitY = rand() % height;
        tail.push_back(prev2);

        // Logique pour le flag
        if (score >= 100000) { // Condition modifiée pour révéler le flag
	    std::string decryptedFlag = encryptDecrypt(encryptedFlag);
            cout << "Congratulations! You've found the flag: " << decryptedFlag << endl;
            gameOver = true;
        }
    }
}

int main() {
    srand(static_cast<unsigned int>(time(0)));
    Setup();
    while (!gameOver) {
        Draw();
        Input();
        Logic();
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    return 0;
}
