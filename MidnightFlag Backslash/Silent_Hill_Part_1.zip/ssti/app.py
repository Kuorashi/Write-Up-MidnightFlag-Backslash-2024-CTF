from flask import Flask, render_template, request, Markup, render_template_string
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('db.sqlite')
    c = conn.cursor()
    c.execute('CREATE TABLE IF NOT EXISTS guests (id INTEGER PRIMARY KEY, name TEXT, date TEXT)')
    conn.commit()
    conn.close()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        name_search = request.form['name']
        # Utilisation de render_template_string pour interpréter les entrées utilisateur comme un template
        result_formatted = render_template_string(f"Recherche effectuée pour : {name_search}")
        return render_template('index.html', results=Markup(result_formatted))
    return render_template('index.html', results=Markup(""))

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000)
